using System;

namespace OuterSpace
{
    /// <summary>
    /// Stores player specific info that is not a part of a crewmember, race, ship, etc.
    /// </summary>
    public class Player
    {
        //private List<FinancialAccounts> finances = new List<FinancialAccounts>();

        //private Ship playerShip;

        //public Ship MyShip
        //{
        //    get { return playerShip; }
        //    set { playerShip = value; }
        //}

        private CrewMgr crewManager = null;

        //private List<Inventory> inventories = new List<Inventory>();

        //private List<MissionsAndOps> missionsAndOps = new List<MissionsAndOps>();
    }
}